from django.db import models

# Create your models here.

class File(models.Model):
    date = models.CharField(max_length=50)
    name = models.CharField(max_length=50)
    text = models.CharField(max_length=10000, default="")
    importance = models.IntegerField(default=5)
    notes = models.CharField(max_length=10000, default="", blank=True)

    def __str__(self):
        return self.name
    
class Term(models.Model):
    phrase = models.CharField(max_length=50)
    inclusive = models.BooleanField
    
class Filter(models.Model):
    dateMaximum = models.CharField(max_length=50)
    dateMinimum = models.CharField(max_length=50)
    importance = models.IntegerField(default=5)
    terms = models.ManyToManyField(Term)

# let filters = { "dateMaximum": null, "dateMinimum": null, "importance": 0, "terms": [] };