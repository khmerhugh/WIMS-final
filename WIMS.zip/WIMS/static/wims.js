// valid username/password combinations
//let users = {"a": "a", "scooby": "mystery"};

// Filters object
let filters = { "dateMaximum": null, "dateMinimum": null, "importance": 0, "terms": [] };

//////////////////////////
// flag for annotations
let f = 0;
// categories for annotations
const categories = [ { "color": "orangered", "type": "Person" },
                     { "color": "blueviolet", "type": "Place" },
                     { "color": "yellowgreen", "type": "Telephone" }
];

// RegEx for importing from supplied case file
const regexp = /--- ((?:fbi|cia|se)\d+\.\S*?)(?:\.*) ---\s*?(?:Report) (?:\S*)\s(.*?\d\d\d\d)(?:\.|:{0,1})\s*(.*)/gm;
// Array of files
let files = [];
files = populateFiles();

/////////////////////////////////
// Hide Main Lower Right Divs
/////////////////////////////////
function hideMLRElements() {
    const elements = document.querySelectorAll(".mlr");
    elements.forEach(element => {
      element.style.display    = "none";
      element.style.visibility = "hidden";
    });
  }

/////////////////////////////////
// Recreate File Div
/////////////////////////////////  
function displayCase(x){

    let file = files.filter(function( obj ) {
        return obj.id == x.substring(1);
    })[0];   

    hideMLRElements();
    document.getElementById("main_lowerright_file").style.display = "block";
    document.getElementById("main_lowerright_file").style.visibility = "visible";
    document.getElementById("main_lowerright_file").innerHTML = 
        "<P>Filename: " + file.name + //files[Number(x.substring(1))][0] + 
        "</P><P>Date: " + file.date + //files[Number(x.substring(1))][1] + "</P>" +
        '<div id="prose">' +
        file.text + //files[Number(x.substring(1))][2] +
        "</div>";

//////////////////////////////////////////////////////////

    let divRangeImportance = document.createElement("DIV");

    let importanceLabel = document.createElement("LABEL");
    importanceLabel.setAttribute("for", "file_importance");
    importanceLabel.innerHTML = "Importance Level:";

    let br = document.createElement("BR");

    let importanceRange = document.createElement("INPUT");
    importanceRange.setAttribute("type", "range");
    importanceRange.setAttribute("id", "file_importance");
    importanceRange.setAttribute("name", "file_importance");
    importanceRange.setAttribute("list", "importance_values");
    importanceRange.setAttribute("min", "0");
    importanceRange.setAttribute("max", "10");
    importanceRange.setAttribute("step", "1");
    importanceRange.setAttribute("value", Number(file.importance) ); //files[Number(x.substring(1))][3]);
    //importanceRange.onchange = function(){ 
    //    files[Number(x.substring(1))][3] = importanceRange.value;
    //    checkFiltered();
    //};

    importanceRange.oninput = function(){
        file.importance = importanceRange.value;
        fetch("/files/" + file.id, {
            method: "PUT",
            body: JSON.stringify(file),
            headers: { "Content-Type": "application/json",
                       "Authorization": "token " + sessionStorage.token } } )
        .then( r => {
            checkFiltered();
        })
    };

    let datalist = document.createElement("DATALIST");
    datalist.setAttribute("id", "importance_values");
    let labels = ["0","","","","","5","","","","","10"];
    for (let i = 0; i<=10; i++){
        let option = document.createElement('option');
        option.value = i;
        option.label = labels[i];
        datalist.appendChild(option);
    }

    divRangeImportance.appendChild(importanceLabel);
    divRangeImportance.appendChild(br);
    divRangeImportance.appendChild(importanceRange);
    divRangeImportance.appendChild(datalist);
    document.getElementById("main_lowerright_file").appendChild(divRangeImportance);

    //////////////////////////////////////////////
    // For Annotations
    /////////////////////////////////////////////
    document.getElementById("prose").addEventListener("mousedown", function () {
            f = 0;
        }, false);
    document.getElementById("prose").addEventListener("mousemove", function () {
            f = 1;
        }, false);
    document.getElementById("prose").addEventListener("mouseup", function () {
            if (f === 0) {
            } else if (f === 1) {
                getSelectedText();
                //files[Number(x.substring(1))][2] = document.getElementById("prose").innerHTML;
                files[Number(x.substring(1))].text = document.getElementById("prose").innerHTML;
            }
        }, false);

    let divAnnotate = document.createElement("DIV");
    let fieldsetAnnotate = document.createElement("FIELDSET");
    fieldsetAnnotate.style.width = "400px";

    let legend = document.createElement("LEGEND");
    legend.innerHTML = "Choose category, then highlight document text to annotate:";
    fieldsetAnnotate.appendChild(legend);

    for(let i = 0; i < categories.length; i++){
        let svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
        svg.setAttribute('width', '12');
        svg.setAttribute('height', '12');
        svg.setAttribute('x', '0');
        svg.setAttribute('y', '0');
        svg.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:xlink", "http://www.w3.org/1999/xlink");
    
        let rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
        rect.setAttribute('x', '0');
        rect.style.fill = categories[i].color;
        rect.setAttribute('width', '12');
        rect.setAttribute('height', '12');
        rect.setAttribute('rx', '2');

        svg.appendChild(rect);

        let l = document.createElement("LABEL");
        l.setAttribute("for", "inputAnnotate"+categories[i].type);
        l.appendChild(svg);
        l.innerHTML = l.innerHTML + " " + categories[i].type;

        let inp = document.createElement("INPUT");
        inp.setAttribute("type", "radio");
        inp.setAttribute("id", "inputAnnotate"+categories[i].type);
        inp.setAttribute("name", "annotateCategory");
        inp.setAttribute("value", categories[i].type);
        if (categories[i].type == "Person") inp.checked = true;

        fieldsetAnnotate.appendChild(inp);
        fieldsetAnnotate.appendChild(l);

        if (i < categories.length - 1) fieldsetAnnotate.appendChild(document.createElement("BR"));
    }
    divAnnotate.appendChild(fieldsetAnnotate);
    document.getElementById("main_lowerright_file").appendChild(divAnnotate);

    let file_notes = document.createElement("TEXTAREA");
    file_notes.innerHTML = file.notes; //files[Number(x.substring(1))][4];
    file_notes.placeholder = "Write notes here.";
    file_notes.cols = 80;
    file_notes.rows = 10;
    file_notes.oninput = function(){
        file.notes = this.value;
        fetch("/files/" + file.id, {
            method: "PUT",
            body: JSON.stringify(file),
            headers: { "Content-Type": "application/json", 
                       "Authorization": "token " + sessionStorage.token } } )
        .then( r => {
        })
    };

    document.getElementById("main_lowerright_file").appendChild(file_notes);

}
/////////////////////////
// Populate the sidetab
/////////////////////////
function listFiles(){ 
    document.getElementById("topSidebarSection").replaceChildren();

    for( let i = 0; i < files.length; i++ ){
        let sidetab = document.createElement("DIV");
        sidetab.classList.add("sidebarItem");
        sidetab.id = "c" + files[i].id;
        sidetab.onclick = function(x) { makeSidebarSelected(x.target.id);
                                        makeSelected("file");
                                        displayCase(x.target.id)
        }; 
        sidetab.innerHTML = files[i].name;
        document.getElementById("topSidebarSection").appendChild(sidetab);
    }
    checkFiltered();
}

//////////////////////////
//  Import the Files/Cases
//////////////////////////
function importCases(){
    let x = document.getElementById("importcases_textarea").value;
    document.getElementById("importcases_textarea").value = "";
    let matchedArray = [...x.matchAll(regexp)];
    let f = [];

    for (let i = 0; i < matchedArray.length; i++){
        f.push({ "name" : matchedArray[i][1], 
                 "date" : matchedArray[i][2], 
                 "text" : matchedArray[i][3], 
                 "importance" : 5, 
                 "notes" : "" })
    }

    fetch("/files", {
        method: "POST",
        body: JSON.stringify(f),
        headers: { "Content-Type": "application/json",
                   "Authorization": "token " + sessionStorage.token }
    } )
    .then(response => response.json())
    .then(r => {
        files = files.concat(r);
        //console.log(r);
        listFiles();
    })
}

/////////////////////////
// Display the new case div
////////////////////////
function addCase(){
    console.log("add case");
    hideMLRElements();
    document.getElementById("main_lowerright_newcase").style.display = "block";
    document.getElementById("main_lowerright_newcase").style.visibility = "visible";
}

/////////////////////////
// remove the selected case
////////////////////////
function removeCase(){
    if ( sessionStorage.token === undefined || 
         sessionStorage.token === "undefined" ) {
       document.getElementById("page_login").classList.remove("hidden");
       document.getElementById("page_main").classList.add("hidden");
    }
    else {
        console.log("remove case");
        const e = document.getElementsByClassName("is-sb-selected");
        if (e.length === 1) {
            // remove above number
            fetch("/files/"+Number(e[0].id.substring(1)),{ 
                method: "DELETE",
                headers: { "Content-Type": "application/json",
                           "Authorization": "token " + sessionStorage.token} })
            .then( res => {
                if (res.status !== 204) {
                    document.getElementById("page_login").classList.remove("hidden");
                    document.getElementById("page_main").classList.add("hidden");
                } 
                else {
                    files = files.filter(function( obj ) {
                        return obj.id != Number(e[0].id.substring(1)) });
                    listFiles();
                    document.getElementById("main_lowerright_file").innerHTML = "";
                    hideMLRElements();
                    document.getElementById("file").classList.remove("is-sb-selected");
                }
            })
        }
    }
}

/////////////////////////
// Display the evaluate div
////////////////////////
function evaluate(){ 
    console.log("evaluate");
    hideMLRElements();
    document.getElementById("main_lowerright_evaluate").style.display = "block";
    document.getElementById("main_lowerright_evaluate").style.visibility = "visible";
}

/////////////////////////
// Display the report div
////////////////////////
function report(){ 
    console.log("report");
    hideMLRElements();
    document.getElementById("main_lowerright_report").style.display = "block";
    document.getElementById("main_lowerright_report").style.visibility = "visible";
}

/////////////////////////
// Display the file div without rebuilding
////////////////////////
function displayFileTab(){
    console.log("display file tab without rebuilding");
    hideMLRElements();
    document.getElementById("main_lowerright_file").style.display = "block";
    document.getElementById("main_lowerright_file").style.visibility = "visible";
}

/////////////////////////
// Display the import div
////////////////////////
function displayImportDiv(){
    console.log("displayImportDiv");
    hideMLRElements();
    document.getElementById("main_lowerright_import").style.display = "block";
    document.getElementById("main_lowerright_import").style.visibility = "visible";
}

/////////////////////////
// Log the current user out
////////////////////////
function logout(){
    sessionStorage.removeItem("token");
    console.log("logout");
    hideMLRElements();
    document.getElementById("logout").classList.remove("is-selected");

    document.getElementById("page_login").classList.remove("hidden");
    document.getElementById("page_main").classList.add("hidden");
}

//////////////////////////////////////
// Add case data from new case page to file array and redraw sidebar
/////////////////////////////////////
function addNewCase(){
    let f = { "name": document.getElementById("newcase_filename").value,
              "date": document.getElementById("newcase_date").value,
              "text": document.getElementById("newcase_textarea").value,
              "importance": document.getElementById("newcase_importance").value,
              "notes": "" };

    fetch("/files/create/",
    {
        method: "POST",
        body: JSON.stringify(f),
        headers: { "Content-Type": "application/json",
                   "Authorization": "token " + sessionStorage.token
        }
    })
    .then(response => response.json())
    .then(r => {
        files.push(r);
        document.getElementById("newcase_filename").value = "";
        document.getElementById("newcase_date").value = "";
        document.getElementById("newcase_textarea").value = "";
        document.getElementById("newcase_importance").value = 5;
        listFiles();
    })
}

/////////////////////////////
// Handle attempted login
/////////////////////////////
function validateUser() {
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;

    //function login(){
        fetch("/login ", {
            method: "POST",
            body: JSON.stringify({ "username": username, 
                                   "password": password } ),
            headers: { "Content-Type": "application/json"}
        })
        .then((res) => {
            if (res.status == 200) {
                document.getElementById("username").value = "";
                document.getElementById("password").value = "";
                document.getElementById("page_login").classList.add("hidden");
                document.getElementById("page_main").classList.remove("hidden");
                return res.json()
            } else {
                sessionStorage.removeItem("token");
                document.getElementById("auth").classList.add("hidden");
                document.getElementById("noauth").classList.remove("hidden");
                throw Error(res.statusText)
            }
        })
        .then(data => {
            sessionStorage.setItem("token", data.token);
            console.log("loginResponse", `sessionStorage set with token value: ${data.token}`);
            //document.getElementById("noauth").classList.add("hidden");
            //document.getElementById("auth").classList.remove("hidden");
        })
        .catch(console.error)
    //}
    //users[newusername] = newpassword;
    //document.getElementById("page_newuser").style.display = "none";
    //document.getElementById("page_newuser").style.visibility = "hidden";
    //document.getElementById("page_login").style.display = "block";
    //document.getElementById("page_login").style.visibility = "visible";
//} else {
//    console.log("Cannot add user");
//}
/**
    if (users[username] === password) {
        console.log("good password");

        // set proper divs to being visible
        document.getElementById("page_login").style.display = "none";
        document.getElementById("page_login").style.visibility = "hidden";
        document.getElementById("page_main").style.display = "block";
        document.getElementById("page_main").style.visibility = "visible";

        // clear username/password textboxes after logging in
        document.getElementById("username").value = "";
        document.getElementById("password").value = "";
    } else {
        // password wrong
        console.log("bad password");
    }
**/
}

/////////////////////////
// Display the add new user div
////////////////////////
function newUser() {
    //document.getElementById("page_login").style.display = "none";
    //document.getElementById("page_login").style.visibility = "hidden";
    //document.getElementById("page_newuser").style.display = "block";
    //document.getElementById("page_newuser").style.visibility = "visible";

    document.getElementById("page_login").classList.add("hidden");
    document.getElementById("page_newuser").classList.remove("hidden");
}

/////////////////////////
// Add a new user given username and password
////////////////////////
function addNewUser() {
    let newusername = document.getElementById("newusername").value;
    let newpassword = document.getElementById("newpassword").value;
    let repeatnewpassword = document.getElementById("repeatnewpassword").value;
    let newemail = document.getElementById("newemail").value;
    if ((newpassword === repeatnewpassword) &&    // passwords dont match
           newusername.length !== 0 &&            // username is blank
           newpassword.length !== 0 &&            // password is blank
           newemail.length !== 0                  // email is blank
           //!users.hasOwnProperty(newusername)     // username already exists
       ) {
        //function signup(){
            fetch("/signup ", {
                method: "POST",
                body: JSON.stringify({ "username": newusername, 
                                       "password": newpassword, 
                                       "email": newemail }),
                headers: { "Content-Type": "application/json"}
            })
            .then((res) => {
                if (res.status == 200) {
                    clearNewUser();
                    document.getElementById("page_newuser").classList.add("hidden");
                    document.getElementById("page_main").classList.remove("hidden");
                    return res.json()
                } else {
                    sessionStorage.removeItem("token");
                    throw Error(res.statusText)
                }
            })
            .then(data => {
                sessionStorage.setItem("token", data.token);
                console.log("loginResponse", `sessionStorage set with token value: ${data.token}`);
                //document.getElementById("noauth").classList.add("hidden");
                //document.getElementById("auth").classList.remove("hidden");
            })
            .catch(console.error)
        }
    }
        //users[newusername] = newpassword;
        //document.getElementById("page_newuser").style.display = "none";
        //document.getElementById("page_newuser").style.visibility = "hidden";
        //document.getElementById("page_login").style.display = "block";
        //document.getElementById("page_login").style.visibility = "visible";
    //} else {
    //    console.log("Cannot add user");
    //}
//}

////////////////////////////////
// Clear textboxes on create new user page
//////////////////////////////////
function clearNewUser() {
    document.getElementById("newusername").value = "";
    document.getElementById("newpassword").value = "";
    document.getElementById("repeatnewpassword").value = "";
    document.getElementById("newemail").value = "";
}

////////////////////////////////////
// Display the filter tab
////////////////////////////////////
function displayFilterTab() {
    /////////////////////////////////
    // Filter Toolbar
    /////////////////////////////////
    document.getElementById("main_lowerright_filter").innerHTML = "";

    let instructions = document.createElement("DIV");
    instructions.setAttribute("id", "filter_instructions");
    instructions.innerHTML = "Selection of the 'Filter' tab above, reveals the tool tab bar below. " +
                             "Select a tab below to select a filtering tool. " +
                             "Files that are filtered out, are displayed with red text in the left sidebar, " +
                             "while files that meet the filter criteria are displayed in grey text. " +
                             "Filters are cumulative.";
    document.getElementById("main_lowerright_filter").appendChild(instructions);

    let filtertoolbar = document.createElement("DIV");
    filtertoolbar.classList.add("toolbar");
    let filtertoolbarsection = document.createElement("DIV");
    filtertoolbarsection.classList.add("toolbarSection");

    let tabtoolbar1 = document.createElement("DIV");
    tabtoolbar1.classList.add("toolbarItem");
    tabtoolbar1.classList.add("toolbarButton");
    tabtoolbar1.setAttribute("id", "tab_importance");
    tabtoolbar1.innerHTML = "Importance";
    tabtoolbar1.onclick = function(x) {
        makeFilterToolbarSelected (x.target.id);

        document.getElementById("filter_tool").innerHTML = "";
        let divRangeImportance = document.createElement("DIV");

        let importanceLabel = document.createElement("LABEL");
        importanceLabel.setAttribute("for", "file_importance_filter");
        importanceLabel.innerHTML = "Minimum Importance Level:";
    
        let importanceRange = document.createElement("INPUT");
        importanceRange.setAttribute("type", "range");
        importanceRange.setAttribute("id", "file_importance_filter");
        importanceRange.setAttribute("name", "file_importance_filter");
        importanceRange.setAttribute("list", "importance_values_filter");
        importanceRange.setAttribute("min", "0");
        importanceRange.setAttribute("max", "10");
        importanceRange.setAttribute("step", "1");
        importanceRange.setAttribute("value", filters.importance);
        importanceRange.onchange = function(){ 
            filters.importance = importanceRange.value;
            checkFiltered();
        };
    
        let datalist = document.createElement("DATALIST");
        datalist.setAttribute("id", "importance_values_filter");
        let labels = ["0","","","","","5","","","","","10"];
        for (let i = 0; i<=10; i++){
            let option = document.createElement('option');
            option.value = i;
            option.label = labels[i];
            datalist.appendChild(option);
        } 
        divRangeImportance.appendChild(importanceLabel);
        divRangeImportance.appendChild(document.createElement("BR"));
        divRangeImportance.appendChild(importanceRange);
        divRangeImportance.appendChild(datalist);
        document.getElementById("filter_tool").appendChild(divRangeImportance);
    }; 

    let tabtoolbar2 = document.createElement("DIV");
    tabtoolbar2.classList.add("toolbarItem");
    tabtoolbar2.classList.add("toolbarButton");
    tabtoolbar2.setAttribute("id", "tab_dates");
    tabtoolbar2.innerHTML = "Dates";
    tabtoolbar2.onclick = function(x) { 
        makeFilterToolbarSelected (x.target.id);
        document.getElementById("filter_tool").innerHTML = "";
        let divMinDate = document.createElement("DIV");
        let labelMinDate = document.createElement("LABEL");
        labelMinDate.setAttribute("for", "minimum_date_filter");
        labelMinDate.innerHTML = "Minimum Date:";
    
        let inputMinDate = document.createElement("INPUT");
        inputMinDate.setAttribute("type", "date");
        inputMinDate.setAttribute("id", "minimum_date_filter");
        inputMinDate.setAttribute("name", "minimum_date_filter");
        inputMinDate.setAttribute("value", filters.dateMinimum);
        inputMinDate.onchange = function(){ 
            filters.dateMinimum = inputMinDate.value;
            document.getElementById("maximum_date_filter").setAttribute("min", inputMinDate.value);
            checkFiltered();
        };
    
        divMinDate.appendChild(labelMinDate);
        divMinDate.appendChild(document.createElement("BR"));
        divMinDate.appendChild(inputMinDate);
        document.getElementById("filter_tool").appendChild(divMinDate);
        document.getElementById("filter_tool").appendChild(document.createElement("P"));
    
        ///////////////////////////////////////
        let divMaxDate = document.createElement("DIV");
        let labelMaxDate = document.createElement("LABEL");
        labelMaxDate.setAttribute("for", "maximum_date_filter");
        labelMaxDate.innerHTML = "Maximum Date:";
    
        let inputMaxDate = document.createElement("INPUT");
        inputMaxDate.setAttribute("type", "date");
        inputMaxDate.setAttribute("id", "maximum_date_filter");
        inputMaxDate.setAttribute("name", "maximum_date_filter");
        inputMaxDate.setAttribute("value", filters.dateMaximum);
        inputMaxDate.onchange = function () {
            filters.dateMaximum = inputMaxDate.value;
            document.getElementById("minimum_date_filter").setAttribute("max", inputMaxDate.value);
            checkFiltered();
        };    
        divMaxDate.appendChild(labelMaxDate);
        divMaxDate.appendChild(document.createElement("BR"));
        divMaxDate.appendChild(inputMaxDate);
        document.getElementById("filter_tool").appendChild(divMaxDate);
    
    }; 

    let tabtoolbar3 = document.createElement("DIV");
    tabtoolbar3.classList.add("toolbarItem");
    tabtoolbar3.classList.add("toolbarButton");
    tabtoolbar3.setAttribute("id", "tab_terms");
    tabtoolbar3.innerHTML = "Terms";
    tabtoolbar3.onclick = function(x) {
        makeFilterToolbarSelected (x.target.id);
        document.getElementById("filter_tool").innerHTML = "";
        let divFilterTerms = document.createElement("DIV");
        let labelFilterTermsTextbox = document.createElement("LABEL");
        labelFilterTermsTextbox.setAttribute("for", "terms_textbox_filter");
        labelFilterTermsTextbox.innerHTML = "Add term to filter list:";
    
        let inputFilterTermsTextbox = document.createElement("INPUT");
        inputFilterTermsTextbox.setAttribute("type", "text");
        inputFilterTermsTextbox.setAttribute("id", "terms_textbox_filter");
        inputFilterTermsTextbox.setAttribute("name", "terms_textbox_filter");
    
        let inputFilterAddButton = document.createElement("INPUT");
        inputFilterAddButton.setAttribute("type", "button");
        inputFilterAddButton.setAttribute("value", "Add Term");
        inputFilterAddButton.onclick = function(){
            //console.log("Button clicked!");
            filters.terms.push([ document.getElementById("terms_textbox_filter").value, 
                                 document.getElementById("filterExclude").checked ]);
            document.getElementById("terms_textbox_filter").value = "";
            document.getElementById("filterExclude").checked = true;
    
            document.getElementById("selectRemoveTerm").replaceChildren()
            for(let i = 0; i < filters.terms.length; i++){
                let option = document.createElement("OPTION");
                option.value = i;
                option.textContent = (filters.terms[i][1] ? "Exclude" : "Include") + ": " + filters.terms[i][0];
                document.getElementById("selectRemoveTerm").appendChild(option);
            }
            checkFiltered();
        };
    
        let fieldsetFilterTerm = document.createElement("FIELDSET");
        let legend = document.createElement("LEGEND");
        legend.innerHTML = "Filter:";
        fieldsetFilterTerm.appendChild(legend);
    
        let labelFilterIncludeRadio = document.createElement("LABEL");
        labelFilterIncludeRadio.setAttribute("for", "filterInclude");
        labelFilterIncludeRadio.innerHTML = "Inclusive";
    
        let inputFilterIncludeRadio = document.createElement("INPUT");
        inputFilterIncludeRadio.setAttribute("type", "radio");
        inputFilterIncludeRadio.setAttribute("id", "filterInclude");
        inputFilterIncludeRadio.setAttribute("name", "filterTermRadio");
        inputFilterIncludeRadio.setAttribute("value", 0);
        inputFilterIncludeRadio.checked = true;
    
        let labelFilterExcludeRadio = document.createElement("LABEL");
        labelFilterExcludeRadio.setAttribute("for", "filterExclude");
        labelFilterExcludeRadio.innerHTML = "Exclusive";
    
        let inputFilterExcludeRadio = document.createElement("INPUT");
        inputFilterExcludeRadio.setAttribute("type", "radio");
        inputFilterExcludeRadio.setAttribute("id", "filterExclude");
        inputFilterExcludeRadio.setAttribute("name", "filterTermRadio");
        inputFilterExcludeRadio.setAttribute("value", 1);
    
        fieldsetFilterTerm.appendChild(inputFilterIncludeRadio);
        fieldsetFilterTerm.appendChild(labelFilterIncludeRadio);
        fieldsetFilterTerm.appendChild(document.createElement("BR"));
        fieldsetFilterTerm.appendChild(inputFilterExcludeRadio);
        fieldsetFilterTerm.appendChild(labelFilterExcludeRadio);
    
        divFilterTerms.appendChild(labelFilterTermsTextbox);
        divFilterTerms.appendChild(inputFilterTermsTextbox);
        divFilterTerms.appendChild(fieldsetFilterTerm);
        divFilterTerms.appendChild(inputFilterAddButton);
    
        let labelRemoveTerm = document.createElement("LABEL");
        labelRemoveTerm.setAttribute("for", "selectRemoveTerm");
        labelRemoveTerm = "Select filter term to remove";
    
        let selectRemoveTerm = document.createElement("SELECT");
        selectRemoveTerm.setAttribute("id", "selectRemoveTerm");
        inputFilterIncludeRadio.setAttribute("size", 10);
    
        for(let i = 0; i < filters.terms.length; i++){
            let option = document.createElement("OPTION");
            option.value = i;
            option.textContent = (filters.terms[i][1] ? "Exclude" : "Include") + ": " + filters.terms[i][0];
            selectRemoveTerm.appendChild(option);
        }
    
        divFilterTerms.appendChild(labelFilterTermsTextbox);
        divFilterTerms.appendChild(document.createElement("BR"));
        divFilterTerms.appendChild(selectRemoveTerm);
    
        document.getElementById("filter_tool").appendChild(divFilterTerms);
    }; 

    filtertoolbarsection.appendChild(tabtoolbar1);
    filtertoolbarsection.appendChild(tabtoolbar2);
    filtertoolbarsection.appendChild(tabtoolbar3);
    filtertoolbar.appendChild(filtertoolbarsection);
    document.getElementById("main_lowerright_filter").appendChild(filtertoolbar);

    let f = document.createElement("DIV");
    f.setAttribute("id", "filter_tool");
    document.getElementById("main_lowerright_filter").appendChild(f);
    //////////////////////////////////////////////////////////////////////

    console.log("filter");
    hideMLRElements();
    document.getElementById("main_lowerright_filter").style.display = "block";
    document.getElementById("main_lowerright_filter").style.visibility = "visible";

}

function makeFilterToolbarSelected (x) { 
    let ids = ["tab_importance","tab_dates","tab_terms"];
    for (let i = 0; i < ids.length; i++){
        document.getElementById(ids[i]).classList.remove("is-fb-selected");
    }
    document.getElementById(x).classList.add("is-fb-selected");
}

//////////////////////////////////////////////
// Execute when Header tab is clicked
/////////////////////////////////////////////
function makeSelected(x){
    let ids = ["import","new","file","filter","evaluate","report","logout"];
    for (let i = 0; i < ids.length; i++){
        document.getElementById(ids[i]).classList.remove("is-tb-selected");
    }
    document.getElementById(x).classList.add("is-tb-selected");
    console.log(x);

    switch (x) {
        case 'new':
            addCase();
            break;
        case 'import':
            displayImportDiv();
            break;
        case 'logout':
            logout();
            break;
        case 'file':
            displayFileTab();
            break;
        case 'filter':
            displayFilterTab();
            break;
        case 'evaluate':
            evaluate();
            break;
        case 'report':
            report();
            break;
        default:
            break;
      }
}

//////////////////////////////////////////////
// Change CSS class of selected sidebar item
/////////////////////////////////////////////
function makeSidebarSelected(x){
    for (const childElement of document.getElementById("topSidebarSection").children) {
      childElement.classList.remove("is-sb-selected");
    }
    document.getElementById(x).classList.add("is-sb-selected");
}

//////////////////////////////////////////////
// For Annotations
/////////////////////////////////////////////
function getSelectedText() {
    var sel = window.getSelection();
    if (sel.getRangeAt && (sel.toString().trim() != "" )) {
        let r = sel.getRangeAt(0);
        let n = document.createElement("SPAN");
        n.classList.add(document.querySelector('input[name="annotateCategory"]:checked').value);
        r.surroundContents(n);
    } 
    sel.empty();
}
//////////////////////////////////////////////////////////
// Strip Markup out of html to prepare for searching
/////////////////////////////////////////////////////////
function stripMarkup(x){
    let d = new DOMParser().parseFromString(x, 'text/html');
    return d.body.textContent || "";
}

function checkFiltered() {
    for (let i = 0; i < files.length; i++){
        if ( ( filters.importance > files[i].importance ) ||
        ( Date.parse(filters.dateMinimum) > Date.parse(files[i].date ) ) ||
        ( Date.parse(filters.dateMaximum) < Date.parse(files[i].date ) ) ) {
            //document.getElementById("c"+i).classList.add("filteredFile");
            document.getElementById("c"+files[i].id).classList.add("filteredFile");
        }
        else {
            try {
                //document.getElementById("c"+i).classList.remove("filteredFile");
                document.getElementById("c"+files[i].id).classList.remove("filteredFile");
            }
            catch{}
        }

        if (filters.terms.length > 0) {
            for (let j = 0; j < filters.terms.length; j++){
                if ( (stripMarkup(files[i].text).includes(filters.terms[j][0]) && !filters.terms[j][1]) ||
                    (!stripMarkup(files[i].text).includes(filters.terms[j][0]) && filters.terms[j][1])
                    ) 
                {
                    //document.getElementById("c"+i).classList.add("filteredFile");
                    document.getElementById("c"+files[i].id).classList.add("filteredFile");
                }
            }
        }
    }
}

window.onload = function() {
    if ( sessionStorage.token === undefined || 
         sessionStorage.token === "undefined"
    ) {
        document.getElementById("page_login").classList.remove("hidden");
    }
    else {
        // test if token is valid
        test_token();
    }
}

function test_token() {
    fetch("/test_token ", {
        method: "GET",
        headers: { "Content-Type": "application/json",
                   "Authorization": "token " + sessionStorage.token  
        }
    })
    .then((res) => {
        if (res.status == 200) {
            document.getElementById("page_login").classList.add("hidden");
            document.getElementById("page_main").classList.remove("hidden");
        } 
        else {
            document.getElementById("page_login").classList.remove("hidden");
            document.getElementById("page_main").classList.add("hidden");
            throw Error(res.statusText)
        }     
    })
    .catch(console.error)
}

function populateFiles() {
    if ( sessionStorage.token === undefined || 
         sessionStorage.token === "undefined" ) {
        document.getElementById("page_login").classList.remove("hidden");
        document.getElementById("page_main").classList.add("hidden");
    }
    else {
        fetch("/files", {
            method: "GET",
            headers: { "Content-Type": "application/json",
                       "Authorization": "token " + sessionStorage.token}
        })
        .then(res => {
            if (res.status !== 200) {
                document.getElementById("page_login").classList.remove("hidden");
                document.getElementById("page_main").classList.add("hidden");
            //    throw Error(res.statusText)
            } 
            else {
                return res.json();
            }
        })
        .then(r => {
            files = r;
            listFiles();
        })
    }
}
